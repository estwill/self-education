#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float get_float(void)
{
 int response = 0;
 float z = 0;
 response = scanf("%f", &z);
 if (response == 1) 
 return z; 
 else {
   printf("Введите целое число и перезапустите программу\n");
   exit(1);
   }
}

int main(void) {
  float a = get_float();
  float b = get_float();
  float c = get_float();
  double d = pow(b, 2) - 4 * a * c;
  float x1, x2;
  double sq = sqrt(d);
  if (a == 0 && b == 0 && c == 0)
  {
    printf("Любое число");
    return 0;
  }
  else if (a == 0 && b == 0)
  {
    printf("Уравнение не имеет решения");
    return 0;
  }
  else if (a == 0)
  {
    x1 = -c / b;
    printf ("x1 = %f",x1);
    return 0;
  }
  if (d < 0)
  {
    printf ("Уравнение не имеет решения. D < 0.");
    return 0;
  }
  else if (d == 0)
  {
    x1 = (-b - sq) / 2 / a;
    printf ("x1 = %f", x1);
    return 0;
  }
  x1 = (-b - sq) / 2 / a;
  x2 = (-b + sq) / 2 / a;
    printf ("x1 = %f", x1);
    printf ("\nx2 = %f", x2);
    return 0;
  }
