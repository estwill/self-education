#include <stdio.h>
#include <stdlib.h>

int get_int(void)
{
 int response = 0;
 int j = 0;
 response = scanf("%i", &j);
 if (response == 1) 
 return j; 
 else {
   printf("Введите число от 0 до 23 и перезапустите программу\n");
   exit(1);
   }
}
int main (void) {
  printf ("Введите число от 0 до 23 и перезапустите программу\n");
  int a = get_int();
  int p,v,b,i;
  if (a >= 0 && a <= 23) {
    printf ("Высота:");
    for (v = 0;v<=a-7;v++){
      printf (" ");
    }
   printf ("%i",a);
  for (i = 0; i<=a-2; i++){
    printf ("\n");
    for (p = 0;p<=a-i;p++)
       printf (" ");
      for (b = 0; b<=i+1; b++)
        printf ("#");
  }
} else {
    printf ("Введите правильное число!");
}
  return 0;
  }
