#include <stdio.h>
float get_float(void) {
 int response = 0;
 float sdach = 0;
 printf ("Введите сумму, а мы расчитаем Вам сдачу.\n");
 response = scanf("%f", &sdach);
 if (response == 1) return sdach; else {
   printf("Введите число и перезапустите программу\n");
   exit(1);
   }
}

int main(void) {
  float sdach = get_float();
  int monet = 0;
  int monet25 = 0;
  int monet10 = 0;
  int monet5 = 0;
  int monet1 = 0;
  int cent = sdach * 100;
  int a = 25;
  int b = 10;
  int c = 5;
  int d = 1;
  if (sdach = 0) {
    printf ("Вам не нужна сдача");
    return 0;
  }
   while(sdach < 0)
        {
            printf ("Введите корректную сумму "); 
            return 0;
        } 
    while(cent >= 25)
        {
            cent = cent - 25;
            monet25 = monet25 + 1;
            monet = monet + 1;
        }
    while(cent >= 10)
        {
            cent = cent - 10;
             monet10 = monet10 + 1;
             monet = monet + 1;
        }
    while(cent >= 5)
        {
            cent = cent - 5;
             monet5 = monet5 + 1;
             monet = monet + 1;
        }
    while(cent > 0)
        {
            cent = cent - 1;
             monet1 = monet1 + 1;
             monet = monet + 1;
        }
    printf("На сдачу нужно %i монет\nКол-во монет по номиналу:\n", monet);
    printf("  25-ти центовых %i монет\n", monet25);
    printf("  10-ти центовых %i монет\n", monet10);
    printf("  5-ти центовых %i монет\n", monet5);
    printf("  1 центовых %i монет\n", monet1);
return 0;
}